

function ausgabe (vorname){
    console.log("Guten Morgen " + vorname )
}

function Einschreiben() {
    let name = document.getElementById
    ("vorname").value;

    ausgabe(name);
}


let anrede = document.getElementById
  ("Herr").checked;


  function getStartnr (min + Math.random()*max);